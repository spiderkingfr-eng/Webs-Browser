WEBS BROWSER
============

One file. No runtime to download, nothing beside it.
Double-click WebStudiosBrowser.exe and it runs. In the browser, Menu >
"What's new" lists all 287 features and where to find each one; Ctrl+/ shows
every keyboard shortcut.


NEW IN THE LATEST UPDATE (15 features)
--------------------------------------
  Music           keep playing while you browse, a Now playing panel in
                  the toolbar, Alt+M to stop or start everything,
                  playlists, internet radio, smooth fades, and music goes
                  quiet while a web page plays sound
  Sounds          ambient sounds (rain, thunderstorm, waves, wind,
                  fireplace, cafe, forest, space, white and brown noise),
                  a sound for focus sessions, alarms that play your songs,
                  sound styles for the sound effects
  Looks           vibes (a color, moving background and sound in one
                  click), rain, snow, embers, fireflies and sunset sea live
                  wallpapers, a music visualizer, a startup animation


THE UPDATE BEFORE THAT (21 features)
------------------------------------
  Music           background music on the new tab page (New tab > Music):
                  add songs from your computer; a button in the bottom-left
                  corner mutes it
  Safety          a tracking grade (A to F) for each site, a warning before
                  programs from new sites, a permission check-up (camera,
                  microphone, location), a PIN for private windows, a
                  temporary email address, and what you type in long text
                  boxes is kept if the page closes
  Tools           scratchpad (Alt+N), text tools on the selection, a
                  calculator in the sidebar, sync between computers through
                  a folder (Settings > Backup and restore), achievements
  New tab and fun a calendar, a habit tracker, more widgets (quote, note,
                  stopwatch, battery), live backgrounds, a daily word puzzle
                  in Games, and a few hidden surprises
  Looks and sound a tiny toolbar, click effects, sound effects


AN EARLIER UPDATE (16 features)
-------------------------------
  Tabs            tab trees in the sidebar, pictures in tab hover cards,
                  group tabs by site, a tab limit, and a warning when a page
                  is already open
  Reading         key points of a page, citations (MLA, APA, Chicago),
                  compare two pages, reading reminders, text size per site,
                  print without clutter
  Video           theater mode, listen only, subtitle style, watch history,
                  sleep timer


AN EARLIER UPDATE (18 features)
-------------------------------
  You and tabs    profiles (separate windows with their own logins, history
                  and settings: Menu > Profiles), tab overview (Alt+W),
                  pause video when you switch tabs, volume per tab, and the
                  keyboard's media keys work with the browser
  Reading         follow sites and see their new posts on the new tab page,
                  continue reading where you stopped, sticky notes and
                  drawing on pages, a readable font, any site's search as an
                  address bar keyword
  Tools and fun   color picker, ruler, stored data per site, theme editor,
                  your browsing recap, games (Web Runner, Snake, 2048), and
                  flip or analog clocks on the new tab page


AN EARLIER UPDATE (18 features)
-------------------------------
  Looks           smooth animations everywhere (Settings > Appearance >
                  Animations: full, reduced or off), seasonal effects on the
                  new tab page, and a theme that turns dark after sunset
  Video and sound volume boost up to 300%, bass or voice boost, A-B loop
                  (Alt+B)
  Browsing        hold Shift over a link to preview it in the sidebar; Alt+G
                  link hints to click with the keyboard; your own shortcuts
                  on Alt+Shift+1 to 9; translate selected text; startup check
  Tools           screenshot editor (arrows, boxes, text, blur, crop);
                  collections of pages with notes; an offline page with a
                  small game that reopens your page when you're back online
  Home            Family safety (blocked sites and a daily limit behind a
                  PIN), data saver, downloads sorted into folders, automatic
                  backups to a folder you choose


AN EARLIER UPDATE (21 features)
-------------------------------
  Video           the speed you pick (Alt+. / Alt+,) is remembered for each
                  site; skip an intro once with Alt+S and later episodes of
                  the show skip it by themselves; a 5 second Next episode
                  countdown when an episode ends (Settings > Video)
  Watched pages   price drop alerts and page change alerts, checked when you
                  open the page, on demand or once a day (Menu > Watched
                  pages, or Ctrl+Shift+P > Watch this page's price)
  Notes           formatted sidebar notes: bold, headings, lists,
                  checklists, quotes, code and links; save as Markdown;
                  export all highlights as Markdown
  Words           Define selected word (Ctrl+Shift+P), or turn on
                  double-click for meanings (Settings > Tools)
  New tab         background slideshow: several pictures, GIFs or videos
                  that change every new tab, hour or day (Background);
                  tip of the day
  Everyday        search the text of all open tabs; "weather in paris" and
                  "btc price" in the address bar; always mute a site;
                  forget the last 15 minutes, hour or day; open the page in
                  a private window; copy title and link


AN EARLIER UPDATE (29 features)
-------------------------------
  Tabs            tab groups (right-click a tab), workspaces (Menu), snooze a
                  tab until later, offers to close tabs you forgot, and a
                  vertical tab list in the sidebar
  Reading         reader view: fonts (including an easy-reading one),
                  spacing, width, five themes, Listen (reads aloud and
                  follows along), Save offline. Highlight text on any page
                  (Alt+H), with notes; all highlights in Sidebar > Reading.
                  Clip a selection to your notes.
  Productivity    clipboard history (Alt+Shift+V), text snippets (;addr),
                  mouse gestures, page load time
  Accessibility   high contrast, grayscale, inverted and color-blind
                  filters, big pointer, link highlighting, break reminders
  Customization   seven color themes, your own CSS for any site,
                  userscripts, choose the toolbar buttons
  Safety          password leak check (Settings > Privacy; the password is
                  never sent) and a warning before look-alike sites such as
                  paypa1.com

  Saving and filling in passwords was already built in (the Edge engine's
  own password manager).


AN EARLIER UPDATE (49 features)
-------------------------------
  Address bar     answers as you type: 100 usd to eur, time in tokyo,
                  3pm est to pst, days until christmas, 15% of 80,
                  tip 20% on 64 split 4, 255 to hex, #e8342a, define <word>,
                  roll 2d6, password 24, timer 10 min. Shift+Delete forgets
                  a history suggestion.
  New tab page    weather, a to-do list, a countdown, your name in the
                  greeting, 24-hour clock, show or hide any section
                  (Customize), a one-off search engine, drag to reorder and
                  right-click to edit shortcuts, background Fill / Fit /
                  Stretch / Center and dim, sharper enlarged backgrounds,
                  video and anime-artwork previews in Continue watching
  Page tools      Menu > Page tools: unlock copy and right-click (per site),
                  clean up pop-ups and sticky bars, edit page text,
                  auto-scroll (Alt+A), word count, page outline, QR code
                  (Alt+Q). Night light for warmer pages. Alt+Up/Down sets a
                  video's volume.
  Focus           focus mode blocks distracting sites (Alt+Shift+F; the list
                  is in Settings > Focus), screen time per site, and in the
                  sidebar: timers, Pomodoro, a stopwatch and the to-do list
  Tabs            command palette (Ctrl+Shift+P), commands and bookmarks in
                  tab search (Ctrl+Shift+A), duplicate (Ctrl+Shift+K), mute
                  (Ctrl+M), copy address (Ctrl+Shift+Y), copy all tab links,
                  add a page to the new tab shortcuts

  Online answers use free services with no account: exchange rates from
  open.er-api.com, weather from open-meteo.com, definitions from
  dictionaryapi.dev, anime artwork from anilist.co and api.jikan.moe, and
  the password check from api.pwnedpasswords.com. Only what you typed (or
  the show's name, or 5 characters of a scrambled password) is sent.


INSTALL, AND MAKE IT YOUR DEFAULT BROWSER
-----------------------------------------
  powershell -ExecutionPolicy Bypass -File install.ps1

Copies the exe to %LOCALAPPDATA%\Programs\Webs Browser\, registers it with
Windows as a browser (for your account only, no admin needed), and adds
"Webs Browser" to the Start menu - type that in Windows search to open it.
Then it opens Settings on the right page: press "Set default" at the top.
Windows lets no program make itself the default; that one click is yours.
The same button is in the browser under Settings > Default browser.

To undo:  "%LOCALAPPDATA%\Programs\Webs Browser\WebStudiosBrowser.exe" --unregister

Updating: run install.ps1 again after a rebuild. If the browser is open it is
not closed - the running copy is renamed aside and the update takes over the
next time you start it.


VPN
---
The globe button in the toolbar (Alt+V). Two ways to connect:

  Free (Tor)      no account and no sign-up. The first time, the official Tor
                  client (about 22 MB) is downloaded from torproject.org and
                  checked against its published SHA-256 checksum. Traffic goes
                  through three volunteer relays: private, but slower than a
                  paid VPN. Pick one of 21 countries, or the fastest.
  My VPN provider the SOCKS5, HTTP or HTTPS proxy server your VPN service
                  gives you, with your login (Settings > VPN; NordVPN and PIA
                  servers are filled in for you). The password is encrypted
                  with your Windows account (DPAPI) and never shown again.

  Kill switch     if the VPN drops, pages stop loading instead of quietly
                  using your real address (on by default)
  Split tunneling every site except a list, or only the sites on a list; the
                  VPN panel turns it off for the site you are on in one click
  New identity    a fresh Tor route and address
  Leak guard      WebRTC is disabled while the VPN is on, so pages cannot
                  learn your real address through it; DNS goes through the
                  VPN too
  Status          the address and country sites see, time connected, data
  Auto-connect    Settings > VPN > Connect when the browser starts

How it works: every page's traffic goes to a small relay inside the browser
(127.0.0.1), which sends each connection directly, through Tor, or through
your provider, and cuts existing connections whenever the route changes.


WHAT IT IS
----------
A real Windows browser. Pages are rendered by the Microsoft Edge WebView2
engine that is already part of Windows, so sites behave exactly as they do in
Edge or Chrome and security fixes arrive with Windows Update. Everything
around the page - tabs, address bar, menus, find, reader, history, the ad
blocker - was built here from scratch.

Requires: Windows 10 or 11. (WebView2 ships with Windows 11 and current
Windows 10. If it is missing, the browser says so on launch.)


SHIELD - THE AD BLOCKER
-----------------------
  Filter lists    the same lists uBlock Origin uses - EasyList, EasyPrivacy,
                  uBlock filters, quick fixes, privacy, badware, unbreak,
                  Peter Lowe's, the URLhaus malware list and EasyList Cookie
                  (~210,000 rules). Downloaded from their publishers on first
                  run and refreshed every few days. A built-in list works
                  offline from the very first launch.
  Network         ad, tracker and malware requests never leave the machine.
                  A few scripts pages depend on (Google Analytics, ad tags,
                  the IMA video SDK) are swapped for harmless stand-ins so the
                  page keeps working.
  Hiding          empty ad boxes and "sponsored" blocks are hidden, including
                  uBlock's :has-text(), :upward(), :style() and :remove().
  Scriptlets      the uBlock scriptlets the lists rely on (set, aopr, acs,
                  nowoif, json-prune, json-prune-fetch-response, trusted-
                  replace-xhr-response...) - this is what beats anti-adblock
                  walls and strips ads out of YouTube's player. Anything that
                  still plays on YouTube is muted and skipped.
  Popups          windows a page opens on its own, and known ad popups even
                  when you clicked. The toast offers "Open" if you wanted it.
  Whole sites     links to ad servers or malware hosts show a warning page
                  instead ("Continue anyway" / "Always allow").
  Cookie pop-ups  "Reject all" is clicked for you where a banner offers it.
  Clean links     utm_, fbclid, gclid and friends are stripped before a page
                  loads.
  Privacy signal  Global Privacy Control is sent with every request.
  Per site        the shield button shows what was blocked on the page and
                  turns Shield off for that site.
  Block element   right-click > "Block element..." or the shield panel, then
                  click whatever is left. It is saved to My filters.
  Your rules      Settings > My filters takes uBlock / EasyList syntax.

  Score on adblock-tester.com: 100 / 100.


PRIVACY
-------
  Secure DNS      encrypted lookups through Cloudflare, Quad9, AdGuard,
                  Mullvad or Google (Settings > Privacy)
  Fingerprinting  hides canvas, graphics card, CPU, memory and battery details
  Site info       click the lock: certificate, cookies, permissions, and
                  per-site switches for Shield, JavaScript, mobile version,
                  dark mode and the VPN; clear or forget one site
  Also            block notification requests, clear cookies on exit,
                  auto-delete old history, stop autoplay, copy clean links


VIDEO
-----
  Alt+P pop out any video, Alt+K play/pause, Alt+J / Alt+L 10 s back/forward,
  Alt+S skip intro (+85 s), Alt+, / Alt+. speed (0.25x to 4x). The video button
  in the toolbar controls every tab that is playing (loop, fill the window,
  save a frame, mute). Long videos you did not finish appear under "Continue
  watching" on the new tab page, and offer to resume where you stopped.
  SponsorBlock skips sponsor reads on YouTube (only a short hash of the video
  id is sent).


WHAT ELSE IT DOES
-----------------
  Tabs            drag to reorder, middle-click to close, audio indicator and
                  mute, Ctrl+Shift+T to reopen, new tabs from a page open
                  beside it. Right-click a tab: pin, color, auto-refresh,
                  sleep now, move to a new window, close duplicates, sort by
                  site, bookmark all. Hover cards, wheel over the strip to
                  switch, Ctrl+Shift+PgUp/PgDn to move.
  Sessions        save a set of tabs and reopen it later; recently closed list
  Sidebar         Ctrl+Shift+E: notes (also per site), reading list, and any
                  site as a web panel (ChatGPT, WhatsApp...)
  Address bar     calculator (2^10/3), unit converter (5 miles to km),
                  suggestions, keywords (yt cats, w, gh, your own), paste and
                  go, copy as Markdown
  Page tools      area screenshot (Ctrl+Shift+S), translate, read aloud, view
                  source, strong password, Google Lens, always on top, open in
                  another browser
  Look            accent colors, compact toolbar, dark mode for every site,
                  new tab clock, shortcuts, and a background picture, GIF
                  or looping video (MP4 or WebM, plays muted)
  Extensions      Chrome Web Store extensions (Settings > Extensions)
  Backup          everything in one file; bookmarks as standard HTML
  Task manager    memory and CPU per tab; end the ones that hang
  Sleeping tabs   tabs you have not looked at for 30 minutes stop running
                  until you come back (Settings > Performance)
  Session         reopens your tabs; only the active one loads straight away
  Address bar     searches history, bookmarks and open tabs as you type; a
                  bare domain opens, anything else searches. !g !d !b !w !s
                  pick an engine for one search. Alt+Enter opens in a new tab.
  HTTPS first     http:// addresses are upgraded, with a fallback for sites
                  that have no HTTPS
  Split view      two tabs side by side; the toolbar follows the side you click
  Reader view     the article alone, three themes, adjustable type
  Find on page    Ctrl+F, "3 of 17", match case
  Private window  its own in-memory profile - nothing is written to disk.
                  Keeps your bookmarks and settings, saves no history.
  Downloads       own manager with pause, resume and cancel
  Library         history, bookmarks and downloads on one searchable page
  Save            full-page screenshot, save as PDF, save page as
  Import          bookmarks from Chrome, Edge or Brave (Settings > Import)
  Themes          dark and light; sites with a dark mode follow along
  One instance    opening the exe again (or a link from another program)
                  goes to the window that is already open
  Remembers       window size and position


KEYBOARD
--------
  Ctrl+T / Ctrl+W          new tab / close tab
  Ctrl+Shift+T             reopen the tab you just closed
  Ctrl+N / Ctrl+Shift+N    new window / new private window
  Ctrl+L, Alt+D, F6        focus the address bar
  Ctrl+Shift+A             search open tabs
  Ctrl+F / Ctrl+G          find on page / next match
  Ctrl+Tab, Ctrl+PgDn      next tab (Shift, or PgUp, for previous)
  Ctrl+1..8 / Ctrl+9       nth tab / last tab
  Ctrl+D                   bookmark this page
  Ctrl+Shift+B             bookmarks bar on and off
  Ctrl+H / Ctrl+J          history / downloads
  Ctrl+P                   print
  Ctrl + + / - / 0         zoom in, out, reset (numpad too)
  Alt+Left / Right / Home  back / forward / home
  F5, Ctrl+Shift+R         reload / reload without cache
  F11                      full screen on and off
  F12, Ctrl+Shift+I        developer tools
  Ctrl+Shift+E             sidebar
  Ctrl+Shift+S             screenshot an area
  Ctrl+Shift+PgUp / PgDn   move the tab left / right
  Alt+V                    VPN panel
  Alt+P / K / J / L / S    video: pop out / play-pause / -10 s / +10 s / skip intro
  Alt+, / Alt+.            video slower / faster
  Ctrl+/                   every shortcut
  Esc                     close the open panel, leave full screen, or stop
                           loading - and web pages still receive it


WHERE YOUR DATA LIVES
---------------------
  %LOCALAPPDATA%\WebStudiosBrowser\

  profile\   cookies, cache, site storage, saved passwords (WebView2's own)
  shield\    downloaded filter lists, and a copy of the Shield settings so
             blocking starts before the window has finished opening
  ui\        the browser's interface, unpacked from the exe on each update
             (ui\user\ holds your new tab background, and ui\user\thumbs\
             the previews on the "Continue watching" cards)
  bin\       WebView2Loader.dll, likewise
  tor\       the Tor client, once you have used the free VPN
  extensions\  extensions you added
  vpn.json   VPN settings; vpn.key the encrypted provider password

History, bookmarks, settings, the download list and your session are kept in
that profile as ordinary browser storage for the address "browser.example",
which is a reserved name that can never belong to a real site. What the
browser fetches by itself: filter lists; Tor, when you first use the free VPN;
search suggestions as you type (off in private windows, and can be turned off);
SponsorBlock segments for YouTube videos. Delete the folder and the browser is
factory-fresh.


BUILDING IT
-----------
  powershell -ExecutionPolicy Bypass -File build.ps1

That is the whole toolchain. It uses csc.exe from the .NET Framework that
Windows already has - no Node, no MSBuild, no SDK to install. The script
draws the icon, then compiles src\*.cs with every UI page, the page scripts,
the built-in filter list and the WebView2 assemblies embedded as resources.

  src\Program.cs         the shell: windows, tabs, events, downloads, keys
  src\Shield.cs          the content blocker: list parser, matching engine,
                         stand-in scripts, link cleaning, list updates
  src\Features.cs        video, site info, screenshots, source, extensions,
                         task manager, sidebar, file dialogs, suggestions
  src\Vpn.cs             the VPN relay, provider and DNS-over-HTTPS client
  src\Tor.cs             downloads, verifies and runs the Tor client
  src\Install.cs         registration with Windows as a browser
  src\Test.cs            the scripted test runner (below)
  ui\chrome.html         the entire browser interface
  ui\shield.js           runs inside web pages: hiding, scriptlets, YouTube,
                         cookie banners, video controls, dark mode,
                         fingerprint protection, SponsorBlock
  ui\picker.js           "Block element"
  ui\regionshot.js       "Screenshot an area"
  ui\shield-builtin.txt  the built-in filter list; edit and rebuild
  ui\newtab.html  history.html  settings.html  reader.html  blocked.html
  ui\side.html  taskmgr.html  source.html  crashed.html  whatsnew.html

Testing: run it with --data=<scratch folder> --test=<script> and it drives
itself through the script, writing results to <script>.log and screenshots
next to it. The --data folder keeps tests away from your real profile.
backup-before-fixes\ holds the previous version, source and exe.


THE ONE DESIGN DECISION WORTH KNOWING
-------------------------------------
The browser's interface is a web page running in its own WebView2 docked at
the top of the window, and it owns all the data. The C# shell owns windows,
events and the blocker, and stores no user data. Menus and dropdowns work by
asking the shell to grow that top pane to an exact pixel height - and to clip
it to the toolbar plus the open menu, so the page stays visible and clickable
around it.

Two catches follow from it. Nothing inside chrome.html may be sized in % or
vh: that page's viewport is the collapsed toolbar, so 100% is about 86px. And
every size it reports is in device pixels, measured with its own
devicePixelRatio - the Windows DPI the shell sees can disagree after a display
scaling change, which is what used to cut the toolbar and dropdowns short at
125%.
